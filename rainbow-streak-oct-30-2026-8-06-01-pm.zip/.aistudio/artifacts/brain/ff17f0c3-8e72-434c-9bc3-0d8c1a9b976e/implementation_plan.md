# Rainbow Streak — Android Habit & Streak Tracker

Rainbow Streak is a focused, vibrant habit and streak tracker for Android that gamifies daily and periodic habits with dynamically shifting flame colors, custom camera proof verification, period-based streak calculations, and reliable notification alarms.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed based on your preferences:

- **UI Framework & Architecture**: Built with Kotlin, XML layouts, ViewBinding, and Material 3 with a single `MainActivity` and 4 tab Fragments (`HomeFragment`, `DetailsFragment`, `FriendsFragment`, `SettingsFragment`).
- **Proof Media System**: Integrated custom CameraX viewfinder supporting both instant photo captures and video recordings saved to app-private storage.
- **Demo & Offline Posture**: In accordance with your demo instructions, online-dependent components are safely isolated:
  - **Friends Tab**: Displays a sleek "Coming Soon" teaser with visual previews of upcoming shared streaks and invite links.
  - **Ad Restore Flow**: Simulates watching rewarded ads instantly without network dependency, advancing the watch counter (e.g. 1/3, 2/3, 3/3) and restoring expired streaks seamlessly.
  - **Data Persistence**: Offline-first Room database storing streaks, check-in history, proof media metadata, and analytics.

---

## 1. Overview & Core Concept

- **What It Does**: Rainbow Streak enables users to build consistency across daily, weekly, monthly, and yearly habits. Every check-in increments the streak counter and interpolates flame color along a gradient (Yellow → Orange → Magenta → Azure). For accountability, habits can require camera proof before marking completion.
- **Target Audience**: Habit builders, students, fitness enthusiasts, and professionals who desire visual progression and strict period rules without clutter.
- **Key Value**: Exact calendar period tracking, customizable active time windows, exempt days, proof media logs, and a 48-hour restore window with simulated ad recovery.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Home Screen & Check-in**:
   - Floating pill navigation bar at bottom with 4 tabs (Home, Details, Friends, Settings).
   - "Add New Streak" full-width warm orange button at the top of the Home tab.
   - List of active streaks as rounded dark cards featuring emoji circle, flame icon tinted by streak length, streak number, title, and period counter.
   - Tapping the round checkbox checks or unchecks the habit. If "Require proof" is active, a dialog prompts to launch the custom camera viewfinder.
2. **Custom Camera Proof**:
   - Shutter button with toggle for Photo and Video modes.
   - Instant capture confirmation preview (Confirm / Retake).
   - Saved directly to private storage and logged to the streak's proof gallery.
3. **Streak Expiry & Restore**:
   - When a streak misses its calendar period or active window, an expiry dialog appears.
   - Users can choose "Restore Streak (Watch Ad)" to trigger the 3-ad (or 5-ad) restore counter or "Reset Streak".
4. **Details & Analytics**:
   - Overview metrics: active streaks count, cumulative streak days, longest streak, completion rate, and ad restores.
   - Privacy-respecting toggle in Settings that blurs the screen and disables tracking when off.
5. **Settings & Theming**:
   - AMOLED true dark theme, light theme, and system default.
   - Notification master switch and test notification trigger.

### Visual Identity & Theme
- **Color Palette**:
  - Background (Dark / AMOLED): `#0D0D11` / `#000000`
  - Surface Card: `#1A1A22` with subtle borders (`#2A2A38`)
  - Accent / Primary: Warm Orange (`#FF7303`)
  - Pill Selected Indicator: Semi-transparent orange pill `#33FF7303` with `#FF7303` icon
  - Flame Color Gradient Stops:
    - Day 1: `#FFF000` (Yellow)
    - Day 30: `#FF7303` (Orange)
    - Day 100: `#FA50FA` (Magenta)
    - Day 364+: `#498CDB` (Sky Blue)
- **Typography & Components**:
  - Material 3 typography with clean sans-serif font weights.
  - 16dp rounded card corners and minimum 48dp touch targets on checkboxes and navigation items.

---

## 3. Key Product Decisions & Trade-Offs

- **XML + ViewBinding vs. Compose**:
  - *Chosen*: XML layouts and ViewBinding across `MainActivity` and 4 Fragments.
  - *Why*: Direct alignment with your explicit architecture requirements and clean separation of layout XML and Fragment lifecycle.
- **CameraX In-App Viewfinder vs. System Intent**:
  - *Chosen*: Embedded CameraX custom capture Fragment/Activity.
  - *Why*: Satisfies strict requirement of blocking external gallery pickers and enforcing in-the-moment proof of habit completion.
- **Exact Calendar Catch-Up & WorkManager**:
  - *Chosen*: Hybrid evaluation — recalculate streak status instantly on app start / resume, backed by exact alarm / WorkManager triggers at 00:00 local time and active window ends.
  - *Why*: Eliminates edge cases where the app is closed during period rollover while keeping battery impact low.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                       MainActivity                          │
│   ┌─────────────────────────────────────────────────────┐   │
│   │ Floating Bottom Navigation Pill (4 Tabs)            │   │
│   └─────────────────────────────────────────────────────┘   │
└──────────────┬──────────────────┬─────────────────┬─────────┘
               │                  │                 │
               ▼                  ▼                 ▼
        ┌──────────────┐   ┌──────────────┐  ┌──────────────┐
        │ HomeFragment │   │DetailsFrag.  │  │SettingsFrag. │
        │              │   │              │  │              │
        │ - Streak List│   │ - Analytics  │  │ - Theme      │
        │ - Add Modal  │   │ - Blurred UI │  │ - Alarms     │
        │ - Checkbox   │   │   (if off)   │  │ - DataStore  │
        └──────┬───────┘   └──────┬───────┘  └──────┬───────┘
               │                  │                 │
               ▼                  ▼                 ▼
┌─────────────────────────────────────────────────────────────┐
│                    ViewModel & Repositories                 │
│  - StreakViewModel        - DetailsViewModel                │
│  - StreakRepository       - AnalyticsRepository             │
├─────────────────────────────────────────────────────────────┤
│                    Room Local Database                      │
│  - StreakEntity (id, name, emoji, freq, streakCount, etc.)  │
│  - ProofMediaEntity (id, streakId, dayNumber, filePath)     │
│  - AnalyticsEntity (restoresCount, bestStreak, totalChecks) │
├─────────────────────────────────────────────────────────────┤
│                    Background Engines                       │
│  - StreakResetWorker (WorkManager daily / window rollover)  │
│  - StreakAlarmReceiver (Exact AlarmManager reminders)       │
│  - CameraX Capture Pipeline (Photo/Video capture)           │
└─────────────────────────────────────────────────────────────┘
```

### Data Model Entities
1. **`StreakEntity`**:
   - `id`: Long (Primary Key)
   - `name`: String
   - `emoji`: String
   - `frequency`: Enum (`DAILY`, `WEEKLY`, `MONTHLY`, `YEARLY`)
   - `currentStreak`: Int
   - `lastCheckedTimestamp`: Long
   - `lastCheckedPeriodKey`: String (e.g. `2026-10-30` or `2026-W44`)
   - `requireProof`: Boolean
   - `activeWindowStart`: String (e.g. `"00:00"`)
   - `activeWindowEnd`: String (e.g. `"23:59"`)
   - `exemptWeekdaysMask`: Int (bitmask of Mon–Sun)
   - `notificationEnabled`: Boolean
   - `notificationTime`: String (e.g. `"16:00"`)
   - `brokenTimestamp`: Long (for 48-hour restore window)
   - `savedPreviousStreak`: Int
2. **`ProofMediaEntity`**:
   - `id`: Long
   - `streakId`: Long
   - `dayNumber`: Int
   - `filePath`: String
   - `isVideo`: Boolean
   - `capturedAt`: Long
3. **`AnalyticsEntity`**:
   - `totalCheckIns`: Int
   - `highestStreakEver`: Int
   - `totalAdRestores`: Int
   - `totalProofsCaptured`: Int
   - `streaksBrokenCount`: Int

### Interactive Component & State Mapping
- **Flame Interpolator (`StreakStyleConfig.kt`)**: Single source of truth containing color stops (`#FFF000` → `#FF7303` → `#FA50FA` → `#498CDB`) and flame level drawables (`ic_fire_level1` through `ic_fire_level4`).
- **Checkbox Toggle**: Validates active window and exempt days. If proof is required, launches `ProofCameraActivity`; on capture callback, increments streak and creates proof record.
- **Restore Dialog**: Watches simulated ads (1/3 → 2/3 → 3/3), restoring the streak to `savedPreviousStreak` upon completion.
