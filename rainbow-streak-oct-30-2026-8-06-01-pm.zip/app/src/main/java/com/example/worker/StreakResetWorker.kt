package com.example.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.RainbowStreakApp

class StreakResetWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? RainbowStreakApp ?: return Result.failure()
        return try {
            app.streakRepository.evaluateAllStreaksCatchUp()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
