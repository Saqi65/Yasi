package com.example

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import com.example.databinding.ActivityMainBinding
import com.example.ui.details.DetailsFragment
import com.example.ui.friends.FriendsFragment
import com.example.ui.home.HomeFragment
import com.example.ui.settings.SettingsFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var currentTab = TAB_HOME

    private val homeFragment by lazy { HomeFragment() }
    private val detailsFragment by lazy { DetailsFragment() }
    private val friendsFragment by lazy { FriendsFragment() }
    private val settingsFragment by lazy { SettingsFragment() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val isNight = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !isNight
            isAppearanceLightNavigationBars = !isNight
        }

        // Handle safe window insets for edge-to-edge
        ViewCompat.setOnApplyWindowInsetsListener(binding.mainContainer) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.mainContainer.updatePadding(
                top = systemBars.top
            )
            // Apply bottom inset to floating bar
            binding.floatingNavBar.translationY = -systemBars.bottom.toFloat() * 0.3f
            insets
        }

        setupNavigation()

        if (savedInstanceState == null) {
            selectTab(TAB_HOME)
        }
    }

    private fun setupNavigation() {
        binding.tabHome.setOnClickListener { selectTab(TAB_HOME) }
        binding.tabDetails.setOnClickListener { selectTab(TAB_HOME + 1) }
        binding.tabFriends.setOnClickListener { selectTab(TAB_HOME + 2) }
        binding.tabSettings.setOnClickListener { selectTab(TAB_HOME + 3) }
    }

    fun selectTab(tabIndex: Int) {
        currentTab = tabIndex
        val targetFragment: Fragment = when (tabIndex) {
            TAB_DETAILS -> DetailsFragment()
            TAB_FRIENDS -> FriendsFragment()
            TAB_SETTINGS -> SettingsFragment()
            else -> HomeFragment()
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.navHostFragment, targetFragment)
            .commitAllowingStateLoss()

        updateNavPills(tabIndex)
    }

    private fun updateNavPills(selectedTab: Int) {
        val tabs = listOf(
            Triple(binding.tabHome, binding.ivTabHome, binding.tvTabHome),
            Triple(binding.tabDetails, binding.ivTabDetails, binding.tvTabDetails),
            Triple(binding.tabFriends, binding.ivTabFriends, binding.tvTabFriends),
            Triple(binding.tabSettings, binding.ivTabSettings, binding.tvTabSettings)
        )

        for (i in tabs.indices) {
            val (container, icon, label) = tabs[i]
            if (i == selectedTab) {
                container.setBackgroundResource(R.drawable.bg_pill_selected)
                icon.setColorFilter(ContextCompat.getColor(this, R.color.brand_orange))
                label.visibility = View.VISIBLE
            } else {
                container.setBackgroundColor(Color.TRANSPARENT)
                icon.setColorFilter(ContextCompat.getColor(this, R.color.grey_unselected))
                label.visibility = View.GONE
            }
        }
    }

    companion object {
        const val TAB_HOME = 0
        const val TAB_DETAILS = 1
        const val TAB_FRIENDS = 2
        const val TAB_SETTINGS = 3
    }
}
