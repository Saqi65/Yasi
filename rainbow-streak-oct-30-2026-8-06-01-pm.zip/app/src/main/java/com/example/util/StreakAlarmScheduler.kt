package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.entity.StreakEntity
import com.example.receiver.StreakAlarmReceiver
import java.util.Calendar

object StreakAlarmScheduler {

    const val ACTION_REMINDER = "com.example.ACTION_STREAK_REMINDER"
    const val ACTION_PERIOD_END = "com.example.ACTION_PERIOD_END"

    const val EXTRA_STREAK_ID = "extra_streak_id"
    const val EXTRA_STREAK_NAME = "extra_streak_name"
    const val EXTRA_STREAK_EMOJI = "extra_streak_emoji"

    fun scheduleStreakReminder(context: Context, streak: StreakEntity) {
        if (!streak.notificationEnabled) {
            cancelStreakReminder(context, streak.id)
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val parts = streak.notificationTime.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 16
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, StreakAlarmReceiver::class.java).apply {
            action = ACTION_REMINDER
            putExtra(EXTRA_STREAK_ID, streak.id)
            putExtra(EXTRA_STREAK_NAME, streak.name)
            putExtra(EXTRA_STREAK_EMOJI, streak.emoji)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (streak.id * 10 + 1).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)
            }
        } catch (_: SecurityException) {}
    }

    fun schedulePeriodEndCheck(context: Context, streak: StreakEntity) {
        val boundaryMillis = StreakPeriodHelper.getNextBoundaryMillis(streak)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, StreakAlarmReceiver::class.java).apply {
            action = ACTION_PERIOD_END
            putExtra(EXTRA_STREAK_ID, streak.id)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (streak.id * 10 + 2).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, boundaryMillis, pendingIntent)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, boundaryMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, boundaryMillis, pendingIntent)
            }
        } catch (_: SecurityException) {}
    }

    fun cancelStreakReminder(context: Context, streakId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, StreakAlarmReceiver::class.java).apply {
            action = ACTION_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (streakId * 10 + 1).toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }
}
