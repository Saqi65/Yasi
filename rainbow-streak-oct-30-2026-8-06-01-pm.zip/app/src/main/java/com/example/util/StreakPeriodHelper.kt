package com.example.util

import com.example.data.entity.StreakEntity
import com.example.data.model.Frequency
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object StreakPeriodHelper {

    /**
     * Bitmask representation of days of week:
     * Mon=1, Tue=2, Wed=4, Thu=8, Fri=16, Sat=32, Sun=64
     */
    fun getDayMask(calendarDayOfWeek: Int): Int {
        return when (calendarDayOfWeek) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 4
            Calendar.THURSDAY -> 8
            Calendar.FRIDAY -> 16
            Calendar.SATURDAY -> 32
            Calendar.SUNDAY -> 64
            else -> 0
        }
    }

    /**
     * Checks if a given timestamp falls on an exempt weekday for this daily streak.
     */
    fun isDayExempt(mask: Int, timeMillis: Long = System.currentTimeMillis()): Boolean {
        if (mask == 0) return false
        val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        val dayMask = getDayMask(cal.get(Calendar.DAY_OF_WEEK))
        return (mask and dayMask) != 0
    }

    /**
     * Calculates the unique period identifier for the given frequency and time.
     */
    fun getCurrentPeriodKey(frequency: Frequency, timeMillis: Long = System.currentTimeMillis()): String {
        val cal = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            timeInMillis = timeMillis
        }

        return when (frequency) {
            Frequency.DAILY -> SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(timeMillis))
            Frequency.WEEKLY -> {
                val year = cal.get(Calendar.YEAR)
                val week = cal.get(Calendar.WEEK_OF_YEAR)
                String.format(Locale.US, "%d-W%02d", year, week)
            }
            Frequency.MONTHLY -> SimpleDateFormat("yyyy-MM", Locale.US).format(Date(timeMillis))
            Frequency.YEARLY -> SimpleDateFormat("yyyy", Locale.US).format(Date(timeMillis))
        }
    }

    /**
     * Calculates the period key for the immediately preceding calendar period.
     */
    fun getPreviousPeriodKey(frequency: Frequency, timeMillis: Long = System.currentTimeMillis()): String {
        val cal = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            timeInMillis = timeMillis
        }

        when (frequency) {
            Frequency.DAILY -> cal.add(Calendar.DAY_OF_YEAR, -1)
            Frequency.WEEKLY -> cal.add(Calendar.WEEK_OF_YEAR, -1)
            Frequency.MONTHLY -> cal.add(Calendar.MONTH, -1)
            Frequency.YEARLY -> cal.add(Calendar.YEAR, -1)
        }

        return getCurrentPeriodKey(frequency, cal.timeInMillis)
    }

    /**
     * Checks if current time is within the active window (e.g. 13:00 to 14:00).
     */
    fun isWithinActiveWindow(windowStart: String, windowEnd: String, timeMillis: Long = System.currentTimeMillis()): Boolean {
        val (startHour, startMinute) = parseTime(windowStart, 0, 0)
        val (endHour, endMinute) = parseTime(windowEnd, 23, 59)

        val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        val currentMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val startTotalMinutes = startHour * 60 + startMinute
        val endTotalMinutes = endHour * 60 + endMinute

        return currentMinutes in startTotalMinutes..endTotalMinutes
    }

    /**
     * Checks if current time is past the active window for today.
     */
    fun isPastActiveWindow(windowEnd: String, timeMillis: Long = System.currentTimeMillis()): Boolean {
        val (endHour, endMinute) = parseTime(windowEnd, 23, 59)
        val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        val currentMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val endTotalMinutes = endHour * 60 + endMinute

        return currentMinutes > endTotalMinutes
    }

    private fun parseTime(timeStr: String, defHour: Int, defMin: Int): Pair<Int, Int> {
        val parts = timeStr.split(":")
        if (parts.size == 2) {
            val h = parts[0].toIntOrNull() ?: defHour
            val m = parts[1].toIntOrNull() ?: defMin
            return Pair(h.coerceIn(0, 23), m.coerceIn(0, 59))
        }
        return Pair(defHour, defMin)
    }

    /**
     * Checks whether the streak is already checked in the current period.
     */
    fun isCheckedInCurrentPeriod(streak: StreakEntity, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val freq = Frequency.fromString(streak.frequency)
        val currentKey = getCurrentPeriodKey(freq, nowMillis)
        return streak.lastCheckedPeriodKey == currentKey
    }

    /**
     * Checks if the streak has expired/broken based on calendar period and active window rules.
     */
    fun isStreakBroken(streak: StreakEntity, nowMillis: Long = System.currentTimeMillis()): Boolean {
        if (streak.currentStreak <= 0) return false
        val freq = Frequency.fromString(streak.frequency)
        val currentKey = getCurrentPeriodKey(freq, nowMillis)

        // Already checked this period -> not broken
        if (streak.lastCheckedPeriodKey == currentKey) return false

        if (freq == Frequency.DAILY) {
            // Check active window
            val windowClosed = isPastActiveWindow(streak.activeWindowEnd, nowMillis)
            val isTodayExempt = isDayExempt(streak.exemptWeekdaysMask, nowMillis)

            // If today is exempt, the streak neither increases nor resets today
            if (isTodayExempt) {
                return false
            }

            // If today's active window closed without a check
            if (windowClosed) {
                return true
            }

            // If window hasn't closed yet today, did the user miss the PREVIOUS non-exempt day?
            val cal = Calendar.getInstance().apply {
                firstDayOfWeek = Calendar.MONDAY
                timeInMillis = nowMillis
            }
            cal.add(Calendar.DAY_OF_YEAR, -1)

            // Step back through previous days if they were exempt
            var daysLookback = 0
            while (daysLookback < 7 && isDayExempt(streak.exemptWeekdaysMask, cal.timeInMillis)) {
                cal.add(Calendar.DAY_OF_YEAR, -1)
                daysLookback++
            }

            val lastRequiredPeriodKey = getCurrentPeriodKey(Frequency.DAILY, cal.timeInMillis)
            if (streak.lastCheckedPeriodKey != lastRequiredPeriodKey) {
                return true
            }

            return false
        } else {
            // For weekly, monthly, yearly: check if last check was in the previous period
            val prevKey = getPreviousPeriodKey(freq, nowMillis)
            if (streak.lastCheckedPeriodKey != prevKey) {
                return true
            }
            return false
        }
    }

    /**
     * Calculates the required ad count to restore a broken streak:
     * - Within 24 hours: 3 ads
     * - Between 24 and 48 hours: 5 ads
     * - After 48 hours: -1 (restore no longer possible)
     */
    fun getRequiredAdsForRestore(brokenTimestamp: Long, nowMillis: Long = System.currentTimeMillis()): Int {
        if (brokenTimestamp <= 0L) return -1
        val elapsedMillis = nowMillis - brokenTimestamp
        val hoursElapsed = elapsedMillis / (1000 * 60 * 60)
        return when {
            hoursElapsed < 24 -> 3
            hoursElapsed < 48 -> 5
            else -> -1
        }
    }

    /**
     * Calculates the next millis when a period or active window ends, for setting exact alarm / worker.
     */
    fun getNextBoundaryMillis(streak: StreakEntity, nowMillis: Long = System.currentTimeMillis()): Long {
        val freq = Frequency.fromString(streak.frequency)
        val cal = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            timeInMillis = nowMillis
        }

        if (freq == Frequency.DAILY) {
            val (endHour, endMinute) = parseTime(streak.activeWindowEnd, 23, 59)
            cal.set(Calendar.HOUR_OF_DAY, endHour)
            cal.set(Calendar.MINUTE, endMinute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            if (cal.timeInMillis <= nowMillis) {
                // If today's window end has passed, schedule for tomorrow's window end
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            return cal.timeInMillis
        } else {
            // End of day today (catch up daily at midnight)
            cal.set(Calendar.HOUR_OF_DAY, 23)
            cal.set(Calendar.MINUTE, 59)
            cal.set(Calendar.SECOND, 59)
            cal.set(Calendar.MILLISECOND, 999)
            return cal.timeInMillis + 1000L
        }
    }
}
