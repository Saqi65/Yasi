package com.example

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.AppDatabase
import com.example.data.repository.AnalyticsRepository
import com.example.data.repository.ProofRepository
import com.example.data.repository.StreakRepository
import com.example.util.NotificationHelper
import com.example.worker.StreakResetWorker
import com.google.android.gms.ads.MobileAds
import java.util.concurrent.TimeUnit

class RainbowStreakApp : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val analyticsRepository by lazy { AnalyticsRepository(this, database.analyticsDao()) }
    val streakRepository by lazy {
        StreakRepository(
            database.streakDao(),
            database.proofDao(),
            database.analyticsDao(),
            analyticsRepository
        )
    }
    val proofRepository by lazy {
        ProofRepository(this, database.proofDao(), analyticsRepository)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Apply saved theme preference on cold start
        try {
            val savedTheme = getSharedPreferences("theme_prefs", android.content.Context.MODE_PRIVATE)
                .getString("app_theme", "SYSTEM") ?: "SYSTEM"
            applyTheme(savedTheme)
        } catch (_: Throwable) {}

        // Create Notification Channel for streak reminders
        try {
            NotificationHelper.createNotificationChannel(this)
        } catch (_: Throwable) {}

        // Initialize Google Mobile Ads SDK safely in background
        try {
            MobileAds.initialize(this) {}
        } catch (_: Throwable) {}

        // Enqueue background streak catchup worker (every 6 hours)
        try {
            val resetWorkRequest = PeriodicWorkRequestBuilder<StreakResetWorker>(6, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "StreakResetWork",
                ExistingPeriodicWorkPolicy.KEEP,
                resetWorkRequest
            )
        } catch (_: Throwable) {}
    }

    companion object {
        lateinit var instance: RainbowStreakApp
            private set

        fun applyTheme(themeMode: String) {
            when (themeMode) {
                "LIGHT" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                "DARK" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
        }
    }
}
