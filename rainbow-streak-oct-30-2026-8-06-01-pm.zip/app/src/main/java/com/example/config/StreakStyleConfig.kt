package com.example.config

import android.graphics.Color
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import com.example.R

/**
 * Single source of truth for streak colors, thresholds, flame icons, and duration formatting.
 * Easily editable config object per project requirements.
 */
object StreakStyleConfig {

    // --- Color Stops (Streak day -> HEX) ---
    val COLOR_DAY_1: Int = Color.parseColor("#FFF000")
    val COLOR_DAY_30: Int = Color.parseColor("#FF7303")
    val COLOR_DAY_100: Int = Color.parseColor("#FA50FA")
    val COLOR_DAY_364: Int = Color.parseColor("#498CDB")

    // --- Thresholds for Flame Level Icons ---
    const val THRESHOLD_LEVEL_2 = 30
    const val THRESHOLD_LEVEL_3 = 100
    const val THRESHOLD_LEVEL_4 = 364

    /**
     * Returns the smoothly interpolated flame color for a given streak counter.
     * Streak 0 (and day 1) use #FFF000.
     * Day 30 is #FF7303, Day 100 is #FA50FA, Day 364+ is #498CDB.
     */
    @ColorInt
    fun getFlameColor(streak: Int): Int {
        if (streak <= 1) return COLOR_DAY_1
        if (streak >= THRESHOLD_LEVEL_4) return COLOR_DAY_364

        return when {
            streak < THRESHOLD_LEVEL_2 -> {
                val fraction = (streak - 1).toFloat() / (THRESHOLD_LEVEL_2 - 1).toFloat()
                interpolateColor(COLOR_DAY_1, COLOR_DAY_30, fraction)
            }
            streak < THRESHOLD_LEVEL_3 -> {
                val fraction = (streak - THRESHOLD_LEVEL_2).toFloat() / (THRESHOLD_LEVEL_3 - THRESHOLD_LEVEL_2).toFloat()
                interpolateColor(COLOR_DAY_30, COLOR_DAY_100, fraction)
            }
            else -> {
                val fraction = (streak - THRESHOLD_LEVEL_3).toFloat() / (THRESHOLD_LEVEL_4 - THRESHOLD_LEVEL_3).toFloat()
                interpolateColor(COLOR_DAY_100, COLOR_DAY_364, fraction)
            }
        }
    }

    /**
     * Linearly interpolates RGB channels between startColor and endColor.
     */
    @ColorInt
    private fun interpolateColor(startColor: Int, endColor: Int, fraction: Float): Int {
        val clampedFraction = fraction.coerceIn(0f, 1f)
        val startA = Color.alpha(startColor)
        val startR = Color.red(startColor)
        val startG = Color.green(startColor)
        val startB = Color.blue(startColor)

        val endA = Color.alpha(endColor)
        val endR = Color.red(endColor)
        val endG = Color.green(endColor)
        val endB = Color.blue(endColor)

        val a = (startA + clampedFraction * (endA - startA)).toInt()
        val r = (startR + clampedFraction * (endR - startR)).toInt()
        val g = (startG + clampedFraction * (endG - startG)).toInt()
        val b = (startB + clampedFraction * (endB - startB)).toInt()

        return Color.argb(a, r, g, b)
    }

    /**
     * Route ALL flame drawable lookups through this function to allow easy swapping
     * of flame artwork in the future.
     */
    @DrawableRes
    fun getFlameDrawableRes(streak: Int): Int {
        return when {
            streak < THRESHOLD_LEVEL_2 -> R.drawable.ic_fire_level1
            streak < THRESHOLD_LEVEL_3 -> R.drawable.ic_fire_level2
            streak < THRESHOLD_LEVEL_4 -> R.drawable.ic_fire_level3
            else -> R.drawable.ic_fire_level4
        }
    }

    /**
     * Formats streak duration in years, months, and days.
     * Uses 365-day years and 30-day months, omitting zero parts.
     * Only shown once streak is above 3 (returns null if streak <= 3).
     * Example: 721 days -> "1 Year, 11 Month, 26 Day"
     */
    fun formatStreakDuration(streak: Int): String? {
        if (streak <= 3) return null

        val years = streak / 365
        val remAfterYears = streak % 365
        val months = remAfterYears / 30
        val days = remAfterYears % 30

        val parts = mutableListOf<String>()
        if (years > 0) parts.add("$years ${if (years == 1) "Year" else "Years"}")
        if (months > 0) parts.add("$months ${if (months == 1) "Month" else "Months"}")
        if (days > 0) parts.add("$days ${if (days == 1) "Day" else "Days"}")

        return if (parts.isEmpty()) null else parts.joinToString(", ")
    }
}
