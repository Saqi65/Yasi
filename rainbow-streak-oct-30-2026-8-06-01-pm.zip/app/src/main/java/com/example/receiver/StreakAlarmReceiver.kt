package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.RainbowStreakApp
import com.example.util.NotificationHelper
import com.example.util.StreakAlarmScheduler
import com.example.util.StreakPeriodHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StreakAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val streakId = intent.getLongExtra(StreakAlarmScheduler.EXTRA_STREAK_ID, -1L)
        if (streakId <= 0L) return

        val app = context.applicationContext as? RainbowStreakApp ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val streak = app.streakRepository.getStreakById(streakId)
                if (streak != null) {
                    when (intent.action) {
                        StreakAlarmScheduler.ACTION_REMINDER -> {
                            val isChecked = StreakPeriodHelper.isCheckedInCurrentPeriod(streak)
                            val isExempt = StreakPeriodHelper.isDayExempt(streak.exemptWeekdaysMask)

                            // Notifications are skipped for a period that is already checked or exempt
                            if (!isChecked && !isExempt && streak.notificationEnabled) {
                                NotificationHelper.showStreakReminder(
                                    context,
                                    streak.id,
                                    streak.name,
                                    streak.emoji
                                )
                            }
                            // Reschedule for tomorrow
                            StreakAlarmScheduler.scheduleStreakReminder(context, streak)
                        }
                        StreakAlarmScheduler.ACTION_PERIOD_END -> {
                            if (StreakPeriodHelper.isStreakBroken(streak)) {
                                app.streakRepository.markStreakBroken(streak)
                            }
                            // Schedule next period end check
                            StreakAlarmScheduler.schedulePeriodEndCheck(context, streak)
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
