package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.RainbowStreakApp
import com.example.util.StreakAlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as? RainbowStreakApp ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Catch-up evaluate any streaks broken while device was off
                app.streakRepository.evaluateAllStreaksCatchUp()

                // Reschedule all active streak alarms
                val allStreaks = app.database.streakDao().getAllStreaksSync()
                for (streak in allStreaks) {
                    if (streak.notificationEnabled) {
                        StreakAlarmScheduler.scheduleStreakReminder(context, streak)
                    }
                    if (streak.currentStreak > 0) {
                        StreakAlarmScheduler.schedulePeriodEndCheck(context, streak)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
