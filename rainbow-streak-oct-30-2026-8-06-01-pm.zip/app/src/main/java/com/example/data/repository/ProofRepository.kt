package com.example.data.repository

import android.content.Context
import com.example.data.dao.ProofDao
import com.example.data.entity.ProofEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class ProofRepository(
    private val context: Context,
    private val proofDao: ProofDao,
    private val analyticsRepository: AnalyticsRepository
) {

    fun getProofsForStreak(streakId: Long): Flow<List<ProofEntity>> {
        return proofDao.getProofsForStreak(streakId)
    }

    suspend fun saveProofMedia(
        streakId: Long,
        dayNumber: Int,
        periodKey: String,
        sourceFile: File,
        isVideo: Boolean
    ): ProofEntity = withContext(Dispatchers.IO) {
        val proofsDir = File(context.filesDir, "streak_proofs").apply {
            if (!exists()) mkdirs()
        }

        val extension = if (isVideo) "mp4" else "jpg"
        val destinationFile = File(proofsDir, "proof_${streakId}_${UUID.randomUUID()}.$extension")

        // Copy source to app-private storage
        FileInputStream(sourceFile).use { input ->
            FileOutputStream(destinationFile).use { output ->
                input.copyTo(output)
            }
        }

        val entity = ProofEntity(
            streakId = streakId,
            dayNumber = dayNumber,
            periodKey = periodKey,
            filePath = destinationFile.absolutePath,
            isVideo = isVideo,
            capturedAt = System.currentTimeMillis()
        )

        val id = proofDao.insertProof(entity)
        analyticsRepository.recordProofCaptured()
        entity.copy(id = id)
    }

    suspend fun deleteProof(proof: ProofEntity) = withContext(Dispatchers.IO) {
        try {
            val file = File(proof.filePath)
            if (file.exists()) file.delete()
        } catch (_: Exception) {}
        proofDao.deleteProof(proof)
    }
}
