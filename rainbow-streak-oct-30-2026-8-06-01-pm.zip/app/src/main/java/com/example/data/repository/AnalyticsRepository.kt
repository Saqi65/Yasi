package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.dao.AnalyticsDao
import com.example.data.entity.AnalyticsEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlin.math.max

private val Context.dataStore by preferencesDataStore(name = "rainbow_streak_prefs")

class AnalyticsRepository(
    private val context: Context,
    private val analyticsDao: AnalyticsDao
) {
    private val KEY_ANALYTICS_ENABLED = booleanPreferencesKey("analytics_enabled")

    val isAnalyticsEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ANALYTICS_ENABLED] ?: true // default ON
    }

    suspend fun setAnalyticsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ANALYTICS_ENABLED] = enabled
        }
        if (!enabled) {
            wipeAnalytics()
        }
    }

    val analytics: Flow<AnalyticsEntity?> = analyticsDao.getAnalytics()

    suspend fun recordStreakCreated(createdAt: Long) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (!isAnalyticsEnabled.first()) return@withContext
        val current = analyticsDao.getAnalyticsSync() ?: AnalyticsEntity()
        val firstCreatedAt = if (current.firstStreakCreatedAt == 0L) createdAt else current.firstStreakCreatedAt
        analyticsDao.insertOrUpdate(current.copy(firstStreakCreatedAt = firstCreatedAt))
    }

    suspend fun recordCheckIn(currentStreakCount: Int) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (!isAnalyticsEnabled.first()) return@withContext
        val current = analyticsDao.getAnalyticsSync() ?: AnalyticsEntity()
        val updated = current.copy(
            totalCheckIns = current.totalCheckIns + 1,
            highestStreakEver = max(current.highestStreakEver, currentStreakCount)
        )
        analyticsDao.insertOrUpdate(updated)
    }

    suspend fun recordAdRestore() = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (!isAnalyticsEnabled.first()) return@withContext
        val current = analyticsDao.getAnalyticsSync() ?: AnalyticsEntity()
        analyticsDao.insertOrUpdate(current.copy(totalAdRestores = current.totalAdRestores + 1))
    }

    suspend fun recordProofCaptured() = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (!isAnalyticsEnabled.first()) return@withContext
        val current = analyticsDao.getAnalyticsSync() ?: AnalyticsEntity()
        analyticsDao.insertOrUpdate(current.copy(totalProofsCaptured = current.totalProofsCaptured + 1))
    }

    suspend fun recordStreakBroken() = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (!isAnalyticsEnabled.first()) return@withContext
        val current = analyticsDao.getAnalyticsSync() ?: AnalyticsEntity()
        analyticsDao.insertOrUpdate(current.copy(streaksBrokenCount = current.streaksBrokenCount + 1))
    }

    suspend fun wipeAnalytics() = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        analyticsDao.clearAnalytics()
    }
}
