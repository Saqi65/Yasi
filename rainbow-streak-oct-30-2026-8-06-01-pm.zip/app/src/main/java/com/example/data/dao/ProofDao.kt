package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.ProofEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProofDao {

    @Query("SELECT * FROM proofs WHERE streakId = :streakId ORDER BY capturedAt DESC")
    fun getProofsForStreak(streakId: Long): Flow<List<ProofEntity>>

    @Query("SELECT * FROM proofs WHERE streakId = :streakId AND periodKey = :periodKey LIMIT 1")
    suspend fun getProofForPeriod(streakId: Long, periodKey: String): ProofEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProof(proof: ProofEntity): Long

    @Delete
    suspend fun deleteProof(proof: ProofEntity)

    @Query("DELETE FROM proofs WHERE streakId = :streakId AND periodKey = :periodKey")
    suspend fun deleteProofForPeriod(streakId: Long, periodKey: String)

    @Query("DELETE FROM proofs WHERE streakId = :streakId")
    suspend fun deleteAllProofsForStreak(streakId: Long)

    @Query("SELECT COUNT(*) FROM proofs")
    suspend fun getTotalProofsCount(): Int
}
