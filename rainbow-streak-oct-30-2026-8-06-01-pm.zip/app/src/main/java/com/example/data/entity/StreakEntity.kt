package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "streaks")
data class StreakEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val emoji: String,
    val frequency: String = "DAILY",
    val currentStreak: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val lastCheckedTimestamp: Long = 0L,
    val lastCheckedPeriodKey: String = "",
    val requireProof: Boolean = false,
    val activeWindowStart: String = "00:00",
    val activeWindowEnd: String = "23:59",
    val exemptWeekdaysMask: Int = 0, // Bitmask: Mon=1, Tue=2, Wed=4, Thu=8, Fri=16, Sat=32, Sun=64
    val notificationEnabled: Boolean = false,
    val notificationTime: String = "16:00",
    val brokenTimestamp: Long = 0L,
    val previousStreakBeforeBreak: Int = 0,
    val adRestoreCount: Int = 0
)
