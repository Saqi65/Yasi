package com.example.data.repository

import com.example.data.dao.AnalyticsDao
import com.example.data.dao.ProofDao
import com.example.data.dao.StreakDao
import com.example.data.entity.AnalyticsEntity
import com.example.data.entity.ProofEntity
import com.example.data.entity.StreakEntity
import com.example.data.model.Frequency
import com.example.util.StreakPeriodHelper
import kotlinx.coroutines.flow.Flow
import java.io.File
import kotlin.math.max

class StreakRepository(
    private val streakDao: StreakDao,
    private val proofDao: ProofDao,
    private val analyticsDao: AnalyticsDao,
    private val analyticsRepository: AnalyticsRepository
) {

    val allStreaks: Flow<List<StreakEntity>> = streakDao.getAllStreaks()

    suspend fun getStreakById(id: Long): StreakEntity? = streakDao.getStreakById(id)

    suspend fun createStreak(
        name: String,
        emoji: String,
        frequency: Frequency,
        requireProof: Boolean = false,
        activeWindowStart: String = "00:00",
        activeWindowEnd: String = "23:59",
        exemptWeekdaysMask: Int = 0,
        notificationEnabled: Boolean = false,
        notificationTime: String = "16:00"
    ): Long = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val streak = StreakEntity(
            name = name.trim(),
            emoji = if (emoji.isBlank()) "🔥" else emoji.trim(),
            frequency = frequency.name,
            currentStreak = 0,
            requireProof = requireProof,
            activeWindowStart = activeWindowStart,
            activeWindowEnd = activeWindowEnd,
            exemptWeekdaysMask = exemptWeekdaysMask,
            notificationEnabled = notificationEnabled,
            notificationTime = notificationTime
        )
        val id = streakDao.insertStreak(streak)
        analyticsRepository.recordStreakCreated(streak.createdAt)
        id
    }

    suspend fun updateStreak(streak: StreakEntity) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        streakDao.updateStreak(streak)
    }

    suspend fun deleteStreak(streak: StreakEntity) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        proofDao.deleteAllProofsForStreak(streak.id)
        streakDao.deleteStreak(streak)
    }

    suspend fun checkIn(streak: StreakEntity): StreakEntity = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val freq = Frequency.fromString(streak.frequency)
        val currentPeriod = StreakPeriodHelper.getCurrentPeriodKey(freq)

        val newStreakCount = streak.currentStreak + 1
        val updated = streak.copy(
            currentStreak = newStreakCount,
            lastCheckedTimestamp = System.currentTimeMillis(),
            lastCheckedPeriodKey = currentPeriod,
            brokenTimestamp = 0L,
            previousStreakBeforeBreak = 0,
            adRestoreCount = 0
        )
        streakDao.updateStreak(updated)
        analyticsRepository.recordCheckIn(newStreakCount)
        updated
    }

    suspend fun uncheck(streak: StreakEntity): StreakEntity = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val freq = Frequency.fromString(streak.frequency)
        val currentPeriod = StreakPeriodHelper.getCurrentPeriodKey(freq)

        if (streak.requireProof) {
            val proof = proofDao.getProofForPeriod(streak.id, currentPeriod)
            if (proof != null) {
                try {
                    val file = File(proof.filePath)
                    if (file.exists()) file.delete()
                } catch (_: Exception) {}
                proofDao.deleteProof(proof)
            }
        }

        val newStreakCount = max(0, streak.currentStreak - 1)
        val updated = streak.copy(
            currentStreak = newStreakCount,
            lastCheckedPeriodKey = ""
        )
        streakDao.updateStreak(updated)
        updated
    }

    suspend fun markStreakBroken(streak: StreakEntity): StreakEntity = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val updated = streak.copy(
            brokenTimestamp = System.currentTimeMillis(),
            previousStreakBeforeBreak = streak.currentStreak,
            currentStreak = 0,
            adRestoreCount = 0
        )
        streakDao.updateStreak(updated)
        analyticsRepository.recordStreakBroken()
        updated
    }

    suspend fun restoreStreak(streak: StreakEntity): StreakEntity = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val restoredStreakCount = if (streak.previousStreakBeforeBreak > 0) streak.previousStreakBeforeBreak else 1
        val freq = Frequency.fromString(streak.frequency)
        val currentPeriod = StreakPeriodHelper.getCurrentPeriodKey(freq)

        val updated = streak.copy(
            currentStreak = restoredStreakCount,
            brokenTimestamp = 0L,
            previousStreakBeforeBreak = 0,
            adRestoreCount = 0,
            lastCheckedPeriodKey = currentPeriod,
            lastCheckedTimestamp = System.currentTimeMillis()
        )
        streakDao.updateStreak(updated)
        analyticsRepository.recordAdRestore()
        updated
    }

    suspend fun resetStreakToZero(streak: StreakEntity): StreakEntity = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val updated = streak.copy(
            currentStreak = 0,
            adRestoreCount = 0
        )
        streakDao.updateStreak(updated)
        updated
    }

    suspend fun incrementAdCount(streak: StreakEntity): Pair<StreakEntity, Boolean> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val required = StreakPeriodHelper.getRequiredAdsForRestore(streak.brokenTimestamp)
        val newAdCount = streak.adRestoreCount + 1

        if (required > 0 && newAdCount >= required) {
            val restored = restoreStreak(streak)
            Pair(restored, true)
        } else {
            val updated = streak.copy(adRestoreCount = newAdCount)
            streakDao.updateStreak(updated)
            Pair(updated, false)
        }
    }

    suspend fun evaluateAllStreaksCatchUp(): List<StreakEntity> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val brokenList = mutableListOf<StreakEntity>()
        val all = streakDao.getAllStreaksSync()
        val now = System.currentTimeMillis()

        for (streak in all) {
            if (streak.currentStreak > 0 && StreakPeriodHelper.isStreakBroken(streak, now)) {
                val broken = markStreakBroken(streak)
                brokenList.add(broken)
            }
        }
        brokenList
    }
}
