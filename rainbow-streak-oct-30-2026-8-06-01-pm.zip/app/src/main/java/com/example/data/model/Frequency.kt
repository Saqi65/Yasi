package com.example.data.model

enum class Frequency(val displayName: String) {
    DAILY("Every day"),
    WEEKLY("Every week"),
    MONTHLY("Every month"),
    YEARLY("Every year");

    companion object {
        fun fromString(value: String): Frequency {
            return try {
                valueOf(value.uppercase())
            } catch (e: Exception) {
                DAILY
            }
        }
    }
}
