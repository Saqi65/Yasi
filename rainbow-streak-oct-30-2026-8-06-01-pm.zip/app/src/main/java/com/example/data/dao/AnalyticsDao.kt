package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.AnalyticsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalyticsDao {

    @Query("SELECT * FROM analytics WHERE id = 1 LIMIT 1")
    fun getAnalytics(): Flow<AnalyticsEntity?>

    @Query("SELECT * FROM analytics WHERE id = 1 LIMIT 1")
    suspend fun getAnalyticsSync(): AnalyticsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(analytics: AnalyticsEntity)

    @Query("DELETE FROM analytics")
    suspend fun clearAnalytics()
}
