package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.StreakEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StreakDao {

    @Query("SELECT * FROM streaks ORDER BY createdAt ASC")
    fun getAllStreaks(): Flow<List<StreakEntity>>

    @Query("SELECT * FROM streaks ORDER BY createdAt ASC")
    fun getAllStreaksSync(): List<StreakEntity>

    @Query("SELECT * FROM streaks WHERE id = :id LIMIT 1")
    suspend fun getStreakById(id: Long): StreakEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStreak(streak: StreakEntity): Long

    @Update
    suspend fun updateStreak(streak: StreakEntity)

    @Delete
    suspend fun deleteStreak(streak: StreakEntity)

    @Query("SELECT COUNT(*) FROM streaks")
    suspend fun getStreaksCount(): Int
}
