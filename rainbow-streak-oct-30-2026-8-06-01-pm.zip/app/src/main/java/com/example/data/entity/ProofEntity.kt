package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "proofs")
data class ProofEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val streakId: Long,
    val dayNumber: Int,
    val periodKey: String,
    val filePath: String,
    val isVideo: Boolean,
    val capturedAt: Long = System.currentTimeMillis()
)
