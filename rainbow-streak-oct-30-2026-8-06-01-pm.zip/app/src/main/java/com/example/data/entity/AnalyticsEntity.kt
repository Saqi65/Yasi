package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "analytics")
data class AnalyticsEntity(
    @PrimaryKey
    val id: Int = 1,
    val totalCheckIns: Int = 0,
    val highestStreakEver: Int = 0,
    val totalAdRestores: Int = 0,
    val totalProofsCaptured: Int = 0,
    val streaksBrokenCount: Int = 0,
    val firstStreakCreatedAt: Long = 0L
)
