package com.example.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.config.StreakStyleConfig
import com.example.data.entity.StreakEntity
import com.example.data.model.Frequency
import com.example.databinding.ItemStreakBinding
import com.example.util.StreakPeriodHelper

class StreakAdapter(
    private val onStreakClick: (StreakEntity) -> Unit,
    private val onCheckboxClick: (StreakEntity, Boolean) -> Unit,
    private val onEmojiClick: (StreakEntity) -> Unit
) : ListAdapter<StreakEntity, StreakAdapter.StreakViewHolder>(StreakDiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StreakViewHolder {
        val binding = ItemStreakBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return StreakViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StreakViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class StreakViewHolder(private val binding: ItemStreakBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(streak: StreakEntity) {
            val context = binding.root.context
            val isChecked = StreakPeriodHelper.isCheckedInCurrentPeriod(streak)
            val freq = Frequency.fromString(streak.frequency)
            val isExemptToday = freq == Frequency.DAILY && StreakPeriodHelper.isDayExempt(streak.exemptWeekdaysMask)
            val isWindowClosed = freq == Frequency.DAILY && !isChecked && StreakPeriodHelper.isPastActiveWindow(streak.activeWindowEnd)

            // Emoji
            binding.tvStreakEmoji.text = streak.emoji

            // Streak number and Flame styling via StreakStyleConfig
            binding.tvStreakNumber.text = streak.currentStreak.toString()
            val flameColor = StreakStyleConfig.getFlameColor(streak.currentStreak)
            val flameDrawableRes = StreakStyleConfig.getFlameDrawableRes(streak.currentStreak)
            binding.ivFlameIcon.setImageResource(flameDrawableRes)
            binding.ivFlameIcon.setColorFilter(flameColor)

            // Name
            binding.tvStreakName.text = streak.name

            // Frequency / Status badge
            when {
                isExemptToday -> {
                    binding.tvFrequencyBadge.text = context.getString(R.string.streak_exempt_today)
                    binding.tvFrequencyBadge.setTextColor(ContextCompat.getColor(context, R.color.grey_unselected))
                }
                isWindowClosed -> {
                    binding.tvFrequencyBadge.text = context.getString(R.string.streak_window_closed)
                    binding.tvFrequencyBadge.setTextColor(ContextCompat.getColor(context, R.color.red_error))
                }
                else -> {
                    binding.tvFrequencyBadge.text = freq.displayName
                    binding.tvFrequencyBadge.setTextColor(ContextCompat.getColor(context, R.color.dark_text_secondary))
                }
            }

            // Duration: shown only once streak is above 3
            val durationText = StreakStyleConfig.formatStreakDuration(streak.currentStreak)
            if (durationText != null) {
                binding.tvStreakDuration.visibility = View.VISIBLE
                binding.tvStreakDuration.text = durationText
            } else {
                binding.tvStreakDuration.visibility = View.GONE
            }

            // Checkbox state: when checked, circle is orange and checkmark is white.
            // When unchecked, circle has grey stroke and checkmark is grey.
            binding.ivCheckIcon.visibility = View.VISIBLE
            if (isChecked) {
                binding.btnRoundCheckbox.setBackgroundResource(R.drawable.bg_round_checkbox_checked)
                binding.ivCheckIcon.setColorFilter(ContextCompat.getColor(context, R.color.white))
            } else {
                binding.btnRoundCheckbox.setBackgroundResource(R.drawable.bg_round_checkbox_unchecked)
                binding.ivCheckIcon.setColorFilter(ContextCompat.getColor(context, R.color.grey_unselected))
            }

            // Click listeners
            binding.btnRoundCheckbox.setOnClickListener {
                onCheckboxClick(streak, isChecked)
            }

            binding.btnEmojiCircle.setOnClickListener {
                onEmojiClick(streak)
            }

            binding.root.setOnClickListener {
                onStreakClick(streak)
            }
        }
    }

    object StreakDiffCallback : DiffUtil.ItemCallback<StreakEntity>() {
        override fun areItemsTheSame(oldItem: StreakEntity, newItem: StreakEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: StreakEntity, newItem: StreakEntity): Boolean {
            return oldItem == newItem
        }
    }
}
