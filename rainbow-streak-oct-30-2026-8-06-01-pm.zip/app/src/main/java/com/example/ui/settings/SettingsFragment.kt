package com.example.ui.settings

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.R
import com.example.databinding.FragmentSettingsBinding
import com.example.util.NotificationHelper
import kotlinx.coroutines.launch

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: SettingsViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.setMasterNotifications(true)
        } else {
            binding.switchMasterNotifications.isChecked = false
            Toast.makeText(
                requireContext(),
                "Notification permission is denied in system settings.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupSpinners()
        setupSwitches()
        setupNotificationButtons()
        observeData()
    }

    private var isUserInteracted = false

    private fun setupSpinners() {
        // Theme Spinner
        val themeOptions = listOf(
            getString(R.string.theme_system),
            getString(R.string.theme_light),
            getString(R.string.theme_dark)
        )
        val themeAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            themeOptions
        )
        binding.spinnerTheme.adapter = themeAdapter

        binding.spinnerTheme.setOnTouchListener { _, _ ->
            isUserInteracted = true
            false
        }

        binding.spinnerTheme.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!isUserInteracted) return
                isUserInteracted = false
                val themeKey = when (position) {
                    1 -> "LIGHT"
                    2 -> "DARK"
                    else -> "SYSTEM"
                }
                viewModel.setTheme(themeKey)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Language Spinner
        val languageOptions = listOf(getString(R.string.language_en))
        val langAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            languageOptions
        )
        binding.spinnerLanguage.adapter = langAdapter
    }

    private fun setupSwitches() {
        // Analytics Toggle
        binding.switchAnalytics.setOnClickListener {
            val isChecked = binding.switchAnalytics.isChecked
            if (!isChecked) {
                // Revert checkbox state until user confirms
                binding.switchAnalytics.isChecked = true

                AlertDialog.Builder(requireContext())
                    .setTitle(R.string.analytics_disable_dialog_title)
                    .setMessage(R.string.analytics_disable_dialog_msg)
                    .setPositiveButton(R.string.btn_confirm_wipe) { _, _ ->
                        binding.switchAnalytics.isChecked = false
                        viewModel.setAnalyticsEnabled(false)
                        Toast.makeText(requireContext(), "Analytics reset and disabled.", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton(R.string.btn_cancel, null)
                    .show()
            } else {
                viewModel.setAnalyticsEnabled(true)
            }
        }

        // Master Notifications Toggle
        binding.switchMasterNotifications.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        return@setOnCheckedChangeListener
                    }
                }
                viewModel.setMasterNotifications(true)
            } else {
                viewModel.setMasterNotifications(false)
            }
        }
    }

    private fun setupNotificationButtons() {
        binding.btnChannelSettings.setOnClickListener {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().packageName)
                    putExtra(Settings.EXTRA_CHANNEL_ID, NotificationHelper.CHANNEL_ID)
                }
            } else {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().packageName)
                }
            }
            try {
                startActivity(intent)
            } catch (_: Exception) {}
        }

        binding.btnTestNotification.setOnClickListener {
            viewModel.sendTestNotification()
            Toast.makeText(requireContext(), R.string.test_notification_sent, Toast.LENGTH_SHORT).show()
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.isAnalyticsEnabled.collect { isEnabled ->
                        binding.switchAnalytics.isChecked = isEnabled
                    }
                }

                launch {
                    viewModel.masterNotificationsEnabled.collect { isEnabled ->
                        binding.switchMasterNotifications.isChecked = isEnabled
                    }
                }

                launch {
                    viewModel.currentTheme.collect { theme ->
                        val pos = when (theme) {
                            "LIGHT" -> 1
                            "DARK" -> 2
                            else -> 0
                        }
                        if (binding.spinnerTheme.selectedItemPosition != pos) {
                            isUserInteracted = false
                            binding.spinnerTheme.setSelection(pos)
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
