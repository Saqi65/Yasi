package com.example.ui.settings

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.RainbowStreakApp
import com.example.util.NotificationHelper
import com.example.util.StreakAlarmScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val Context.settingsDataStore by preferencesDataStore(name = "rainbow_streak_settings")

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RainbowStreakApp
    private val analyticsRepo = app.analyticsRepository
    private val streakRepo = app.streakRepository

    private val KEY_THEME = stringPreferencesKey("app_theme")
    private val KEY_LANGUAGE = stringPreferencesKey("app_language")
    private val KEY_MASTER_NOTIFICATIONS = booleanPreferencesKey("master_notifications")

    val isAnalyticsEnabled: StateFlow<Boolean> = analyticsRepo.isAnalyticsEnabled
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    val currentTheme: Flow<String> = app.settingsDataStore.data.map { prefs ->
        prefs[KEY_THEME] ?: app.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
            .getString("app_theme", "SYSTEM") ?: "SYSTEM"
    }

    val currentLanguage: Flow<String> = app.settingsDataStore.data.map { prefs ->
        prefs[KEY_LANGUAGE] ?: "en"
    }

    val masterNotificationsEnabled: Flow<Boolean> = app.settingsDataStore.data.map { prefs ->
        prefs[KEY_MASTER_NOTIFICATIONS] ?: false
    }

    fun setTheme(theme: String) {
        app.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("app_theme", theme)
            .apply()

        viewModelScope.launch {
            app.settingsDataStore.edit { prefs ->
                prefs[KEY_THEME] = theme
            }
            RainbowStreakApp.applyTheme(theme)
        }
    }

    fun setLanguage(language: String) {
        viewModelScope.launch {
            app.settingsDataStore.edit { prefs ->
                prefs[KEY_LANGUAGE] = language
            }
        }
    }

    fun setAnalyticsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            analyticsRepo.setAnalyticsEnabled(enabled)
        }
    }

    fun setMasterNotifications(enabled: Boolean) {
        viewModelScope.launch {
            app.settingsDataStore.edit { prefs ->
                prefs[KEY_MASTER_NOTIFICATIONS] = enabled
            }
            val allStreaks = app.database.streakDao().getAllStreaksSync()
            for (streak in allStreaks) {
                val updated = streak.copy(notificationEnabled = enabled)
                streakRepo.updateStreak(updated)
                if (enabled) {
                    StreakAlarmScheduler.scheduleStreakReminder(app, updated)
                } else {
                    StreakAlarmScheduler.cancelStreakReminder(app, updated.id)
                }
            }
        }
    }

    fun sendTestNotification() {
        NotificationHelper.showTestNotification(app)
    }
}
