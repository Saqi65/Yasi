package com.example.ui.home

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.example.R
import com.example.RainbowStreakApp
import com.example.data.entity.ProofEntity
import com.example.data.entity.StreakEntity
import com.example.data.model.Frequency
import com.example.databinding.DialogAddStreakBinding
import com.example.databinding.DialogProofDetailBinding
import com.example.databinding.DialogProofGalleryBinding
import com.example.databinding.DialogProofPromptBinding
import com.example.databinding.DialogStreakEndedBinding
import com.example.databinding.FragmentHomeBinding
import com.example.ui.proof.ProofCameraActivity
import com.example.ui.proof.ProofGalleryAdapter
import com.example.util.StreakPeriodHelper
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var streakAdapter: StreakAdapter

    private var pendingProofStreakId: Long? = null

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == AppCompatActivity.RESULT_OK && result.data != null) {
            val path = result.data?.getStringExtra(ProofCameraActivity.EXTRA_CAPTURED_PATH)
            val isVideo = result.data?.getBooleanExtra(ProofCameraActivity.EXTRA_IS_VIDEO, false) ?: false
            val streakId = pendingProofStreakId

            if (streakId != null && path != null) {
                viewModel.confirmProofAndCheckIn(streakId, path, isVideo)
                Toast.makeText(requireContext(), "Proof captured and streak marked!", Toast.LENGTH_SHORT).show()
            }
        }
        pendingProofStreakId = null
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        streakAdapter = StreakAdapter(
            onStreakClick = { streak ->
                if (streak.brokenTimestamp > 0L) {
                    showStreakEndedDialog(streak)
                } else {
                    showAddOrEditStreakDialog(streak)
                }
            },
            onCheckboxClick = { streak, isChecked ->
                viewModel.handleCheckToggle(streak, isChecked) { streakNeedingProof ->
                    showProofPromptDialog(streakNeedingProof)
                }
            },
            onEmojiClick = { streak ->
                if (streak.requireProof) {
                    showProofGalleryDialog(streak)
                } else {
                    Toast.makeText(
                        requireContext(),
                        R.string.streak_proof_needed_hint,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )

        binding.rvStreaks.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = streakAdapter
        }
    }

    private fun setupListeners() {
        binding.btnAddNewStreak.setOnClickListener {
            showAddOrEditStreakDialog(null)
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.streaks.collect { streaks ->
                        streakAdapter.submitList(streaks)
                        if (streaks.isEmpty()) {
                            binding.layoutEmptyState.visibility = View.VISIBLE
                            binding.rvStreaks.visibility = View.GONE
                        } else {
                            binding.layoutEmptyState.visibility = View.GONE
                            binding.rvStreaks.visibility = View.VISIBLE
                        }
                    }
                }

                launch {
                    viewModel.brokenStreakEvent.collect { brokenStreak ->
                        if (isAdded && context != null && !isDetached) {
                            showStreakEndedDialog(brokenStreak)
                        }
                    }
                }
            }
        }
    }

    private fun showAddOrEditStreakDialog(existingStreak: StreakEntity?) {
        val dialogBinding = DialogAddStreakBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        var selectedFrequency = existingStreak?.let { Frequency.fromString(it.frequency) } ?: Frequency.DAILY
        var selectedExemptMask = existingStreak?.exemptWeekdaysMask ?: 0
        var startTime = existingStreak?.activeWindowStart ?: "00:00"
        var endTime = existingStreak?.activeWindowEnd ?: "23:59"
        var notificationTime = existingStreak?.notificationTime ?: "16:00"

        dialogBinding.btnStartTime.text = startTime
        dialogBinding.btnEndTime.text = endTime
        dialogBinding.btnNotificationTime.text = notificationTime

        if (existingStreak != null) {
            dialogBinding.tvDialogTitle.text = getString(R.string.edit_streak_title)
            dialogBinding.etStreakName.setText(existingStreak.name)
            dialogBinding.etStreakEmoji.setText(existingStreak.emoji)
            dialogBinding.switchRequireProof.isChecked = existingStreak.requireProof
            dialogBinding.switchNotification.isChecked = existingStreak.notificationEnabled
            dialogBinding.layoutNotificationTime.visibility = if (existingStreak.notificationEnabled) View.VISIBLE else View.GONE
            dialogBinding.btnDeleteStreak.visibility = View.VISIBLE

            when (selectedFrequency) {
                Frequency.DAILY -> dialogBinding.rbDaily.isChecked = true
                Frequency.WEEKLY -> dialogBinding.rbWeekly.isChecked = true
                Frequency.MONTHLY -> dialogBinding.rbMonthly.isChecked = true
                Frequency.YEARLY -> dialogBinding.rbYearly.isChecked = true
            }
            dialogBinding.layoutDailyOnlyOptions.visibility = if (selectedFrequency == Frequency.DAILY) View.VISIBLE else View.GONE
        }

        // Preset emoji click listeners
        val presets = listOf(
            dialogBinding.emojiPreset1,
            dialogBinding.emojiPreset2,
            dialogBinding.emojiPreset3,
            dialogBinding.emojiPreset4,
            dialogBinding.emojiPreset5,
            dialogBinding.emojiPreset6
        )
        for (preset in presets) {
            preset.setOnClickListener {
                dialogBinding.etStreakEmoji.setText(preset.text)
            }
        }

        // Frequency change listener
        dialogBinding.rgFrequency.setOnCheckedChangeListener { _, checkedId ->
            selectedFrequency = when (checkedId) {
                R.id.rbWeekly -> Frequency.WEEKLY
                R.id.rbMonthly -> Frequency.MONTHLY
                R.id.rbYearly -> Frequency.YEARLY
                else -> Frequency.DAILY
            }
            // Active window and exempt days apply to DAILY only
            dialogBinding.layoutDailyOnlyOptions.visibility =
                if (selectedFrequency == Frequency.DAILY) View.VISIBLE else View.GONE
        }

        // Active window pickers
        dialogBinding.btnStartTime.setOnClickListener {
            val parts = startTime.split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: 0
            val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
            TimePickerDialog(requireContext(), { _, hourOfDay, minute ->
                startTime = String.format(Locale.US, "%02d:%02d", hourOfDay, minute)
                dialogBinding.btnStartTime.text = startTime
            }, h, m, true).show()
        }

        dialogBinding.btnEndTime.setOnClickListener {
            val parts = endTime.split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: 23
            val m = parts.getOrNull(1)?.toIntOrNull() ?: 59
            TimePickerDialog(requireContext(), { _, hourOfDay, minute ->
                endTime = String.format(Locale.US, "%02d:%02d", hourOfDay, minute)
                dialogBinding.btnEndTime.text = endTime
            }, h, m, true).show()
        }

        // Exempt weekday chip toggles
        fun updateChip(chip: TextView, maskVal: Int) {
            val isSelected = (selectedExemptMask and maskVal) != 0
            chip.setBackgroundResource(if (isSelected) R.drawable.bg_day_selected else R.drawable.bg_day_unselected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), if (isSelected) R.color.white else R.color.dark_text_primary))
        }

        val chips = listOf(
            Pair(dialogBinding.chipMon, 1),
            Pair(dialogBinding.chipTue, 2),
            Pair(dialogBinding.chipWed, 4),
            Pair(dialogBinding.chipThu, 8),
            Pair(dialogBinding.chipFri, 16),
            Pair(dialogBinding.chipSat, 32),
            Pair(dialogBinding.chipSun, 64)
        )
        for ((chip, maskVal) in chips) {
            updateChip(chip, maskVal)
            chip.setOnClickListener {
                selectedExemptMask = selectedExemptMask xor maskVal
                updateChip(chip, maskVal)
            }
        }

        // Notification toggle
        dialogBinding.switchNotification.setOnCheckedChangeListener { _, isChecked ->
            dialogBinding.layoutNotificationTime.visibility = if (isChecked) View.VISIBLE else View.GONE
        }
        dialogBinding.btnNotificationTime.setOnClickListener {
            val parts = notificationTime.split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: 16
            val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
            TimePickerDialog(requireContext(), { _, hourOfDay, minute ->
                notificationTime = String.format(Locale.US, "%02d:%02d", hourOfDay, minute)
                dialogBinding.btnNotificationTime.text = notificationTime
            }, h, m, true).show()
        }

        dialogBinding.btnCancelStreak.setOnClickListener {
            dialog.dismiss()
        }

        dialogBinding.btnDeleteStreak.setOnClickListener {
            if (existingStreak != null) {
                viewModel.deleteStreak(existingStreak)
            }
            dialog.dismiss()
        }

        dialogBinding.btnSaveStreak.setOnClickListener {
            val name = dialogBinding.etStreakName.text.toString().trim()
            if (name.isEmpty()) {
                dialogBinding.etStreakName.error = "Name cannot be empty"
                return@setOnClickListener
            }

            var emoji = dialogBinding.etStreakEmoji.text.toString().trim()
            if (emoji.isEmpty()) emoji = "🔥"

            val requireProof = dialogBinding.switchRequireProof.isChecked
            val notificationEnabled = dialogBinding.switchNotification.isChecked

            if (existingStreak == null) {
                viewModel.createStreak(
                    name = name,
                    emoji = emoji,
                    frequency = selectedFrequency,
                    requireProof = requireProof,
                    activeWindowStart = startTime,
                    activeWindowEnd = endTime,
                    exemptWeekdaysMask = selectedExemptMask,
                    notificationEnabled = notificationEnabled,
                    notificationTime = notificationTime
                )
            } else {
                val updated = existingStreak.copy(
                    name = name,
                    emoji = emoji,
                    frequency = selectedFrequency.name,
                    requireProof = requireProof,
                    activeWindowStart = startTime,
                    activeWindowEnd = endTime,
                    exemptWeekdaysMask = selectedExemptMask,
                    notificationEnabled = notificationEnabled,
                    notificationTime = notificationTime
                )
                viewModel.updateStreak(updated)
            }

            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showProofPromptDialog(streak: StreakEntity) {
        val dialogBinding = DialogProofPromptBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        dialogBinding.btnUploadProof.setOnClickListener {
            dialog.dismiss()
            pendingProofStreakId = streak.id
            val intent = Intent(requireContext(), ProofCameraActivity::class.java)
            cameraLauncher.launch(intent)
        }

        dialogBinding.btnLater.setOnClickListener {
            // Closes dialog, checkbox stays unchecked
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showProofGalleryDialog(streak: StreakEntity) {
        val dialogBinding = DialogProofGalleryBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val galleryAdapter = ProofGalleryAdapter { proof ->
            showEnlargedProofDialog(proof)
        }

        dialogBinding.rvProofGallery.adapter = galleryAdapter
        dialogBinding.btnCloseGallery.setOnClickListener {
            dialog.dismiss()
        }

        val app = requireContext().applicationContext as RainbowStreakApp
        viewLifecycleOwner.lifecycleScope.launch {
            app.proofRepository.getProofsForStreak(streak.id).collect { proofs ->
                galleryAdapter.submitList(proofs)
                if (proofs.isEmpty()) {
                    dialogBinding.tvEmptyGallery.visibility = View.VISIBLE
                    dialogBinding.rvProofGallery.visibility = View.GONE
                } else {
                    dialogBinding.tvEmptyGallery.visibility = View.GONE
                    dialogBinding.rvProofGallery.visibility = View.VISIBLE
                }
            }
        }

        dialog.show()
    }

    private fun showEnlargedProofDialog(proof: ProofEntity) {
        val dialogBinding = DialogProofDetailBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        dialogBinding.tvEnlargedCaptureDate.text = getString(
            R.string.captured_on,
            sdf.format(Date(proof.capturedAt))
        )

        val file = File(proof.filePath)
        if (proof.isVideo) {
            dialogBinding.videoEnlargedPlayback.visibility = View.VISIBLE
            dialogBinding.ivEnlargedPhoto.visibility = View.GONE
            dialogBinding.videoEnlargedPlayback.setVideoURI(Uri.fromFile(file))
            dialogBinding.videoEnlargedPlayback.start()
        } else {
            dialogBinding.ivEnlargedPhoto.visibility = View.VISIBLE
            dialogBinding.videoEnlargedPlayback.visibility = View.GONE
            dialogBinding.ivEnlargedPhoto.load(file)
        }

        dialogBinding.btnCloseDetail.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showStreakEndedDialog(streak: StreakEntity) {
        val dialogBinding = DialogStreakEndedBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        dialogBinding.tvStreakEndedTitle.text = getString(R.string.streak_ended_title, streak.name)

        var currentStreakState = streak
        val requiredAds = StreakPeriodHelper.getRequiredAdsForRestore(currentStreakState.brokenTimestamp)

        fun updateAdButton() {
            val req = StreakPeriodHelper.getRequiredAdsForRestore(currentStreakState.brokenTimestamp)
            if (req <= 0) {
                dialogBinding.btnRestoreAd.isEnabled = false
                dialogBinding.btnRestoreAd.text = getString(R.string.restore_expired_msg)
            } else {
                dialogBinding.btnRestoreAd.text = getString(
                    R.string.restore_streak_btn,
                    currentStreakState.adRestoreCount,
                    req
                )
            }
        }

        updateAdButton()

        // Per user request: Demo mode simulates watching ads instantly without remote network dependency
        dialogBinding.btnRestoreAd.setOnClickListener {
            viewModel.watchRestoreAd(currentStreakState) { isFullyRestored, updatedStreak ->
                currentStreakState = updatedStreak
                if (isFullyRestored) {
                    Toast.makeText(requireContext(), R.string.restore_success, Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                } else {
                    updateAdButton()
                    Toast.makeText(requireContext(), "Ad watched! (${updatedStreak.adRestoreCount}/$requiredAds)", Toast.LENGTH_SHORT).show()
                }
            }
        }

        dialogBinding.btnResetStreak.setOnClickListener {
            viewModel.resetStreak(streak)
            dialog.dismiss()
        }

        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
