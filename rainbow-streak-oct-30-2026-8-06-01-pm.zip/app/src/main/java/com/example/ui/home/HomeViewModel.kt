package com.example.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.RainbowStreakApp
import com.example.data.entity.StreakEntity
import com.example.data.model.Frequency
import com.example.util.StreakAlarmScheduler
import com.example.util.StreakPeriodHelper
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RainbowStreakApp
    private val streakRepo = app.streakRepository
    private val proofRepo = app.proofRepository

    val streaks: StateFlow<List<StreakEntity>> = streakRepo.allStreaks
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _brokenStreakEvent = MutableSharedFlow<StreakEntity>()
    val brokenStreakEvent: SharedFlow<StreakEntity> = _brokenStreakEvent

    init {
        // Run catch-up on launch
        viewModelScope.launch {
            val brokenList = streakRepo.evaluateAllStreaksCatchUp()
            if (brokenList.isNotEmpty()) {
                _brokenStreakEvent.emit(brokenList.first())
            }
        }
    }

    fun createStreak(
        name: String,
        emoji: String,
        frequency: Frequency,
        requireProof: Boolean,
        activeWindowStart: String,
        activeWindowEnd: String,
        exemptWeekdaysMask: Int,
        notificationEnabled: Boolean,
        notificationTime: String
    ) {
        viewModelScope.launch {
            val id = streakRepo.createStreak(
                name = name,
                emoji = emoji,
                frequency = frequency,
                requireProof = requireProof,
                activeWindowStart = activeWindowStart,
                activeWindowEnd = activeWindowEnd,
                exemptWeekdaysMask = exemptWeekdaysMask,
                notificationEnabled = notificationEnabled,
                notificationTime = notificationTime
            )

            val created = streakRepo.getStreakById(id) ?: return@launch
            if (notificationEnabled) {
                StreakAlarmScheduler.scheduleStreakReminder(app, created)
            }
            StreakAlarmScheduler.schedulePeriodEndCheck(app, created)
        }
    }

    fun updateStreak(streak: StreakEntity) {
        viewModelScope.launch {
            streakRepo.updateStreak(streak)
            if (streak.notificationEnabled) {
                StreakAlarmScheduler.scheduleStreakReminder(app, streak)
            } else {
                StreakAlarmScheduler.cancelStreakReminder(app, streak.id)
            }
            StreakAlarmScheduler.schedulePeriodEndCheck(app, streak)
        }
    }

    fun deleteStreak(streak: StreakEntity) {
        viewModelScope.launch {
            StreakAlarmScheduler.cancelStreakReminder(app, streak.id)
            streakRepo.deleteStreak(streak)
        }
    }

    fun handleCheckToggle(
        streak: StreakEntity,
        isChecked: Boolean,
        onRequireProof: (StreakEntity) -> Unit
    ) {
        viewModelScope.launch {
            val freq = Frequency.fromString(streak.frequency)
            val isExempt = freq == Frequency.DAILY && StreakPeriodHelper.isDayExempt(streak.exemptWeekdaysMask)
            if (isExempt) return@launch

            val isWindowClosed = freq == Frequency.DAILY && !isChecked && StreakPeriodHelper.isPastActiveWindow(streak.activeWindowEnd)
            if (isWindowClosed) return@launch

            if (isChecked) {
                // User is unchecking
                streakRepo.uncheck(streak)
            } else {
                // User is checking
                if (streak.requireProof) {
                    onRequireProof(streak)
                } else {
                    streakRepo.checkIn(streak)
                }
            }
        }
    }

    fun confirmProofAndCheckIn(streakId: Long, tempFilePath: String, isVideo: Boolean) {
        viewModelScope.launch {
            val streak = streakRepo.getStreakById(streakId) ?: return@launch
            val nextDayNumber = streak.currentStreak + 1
            val freq = Frequency.fromString(streak.frequency)
            val periodKey = StreakPeriodHelper.getCurrentPeriodKey(freq)

            val tempFile = File(tempFilePath)
            if (tempFile.exists()) {
                proofRepo.saveProofMedia(
                    streakId = streakId,
                    dayNumber = nextDayNumber,
                    periodKey = periodKey,
                    sourceFile = tempFile,
                    isVideo = isVideo
                )
                try {
                    tempFile.delete()
                } catch (_: Exception) {}
            }

            streakRepo.checkIn(streak)
        }
    }

    fun watchRestoreAd(streak: StreakEntity, onResult: (isFullyRestored: Boolean, updatedStreak: StreakEntity) -> Unit) {
        viewModelScope.launch {
            val (updated, isRestored) = streakRepo.incrementAdCount(streak)
            onResult(isRestored, updated)
        }
    }

    fun resetStreak(streak: StreakEntity) {
        viewModelScope.launch {
            streakRepo.resetStreakToZero(streak)
        }
    }
}
