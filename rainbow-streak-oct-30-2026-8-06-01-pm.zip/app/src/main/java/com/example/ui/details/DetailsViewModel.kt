package com.example.ui.details

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.RainbowStreakApp
import com.example.data.entity.AnalyticsEntity
import com.example.data.entity.StreakEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class DetailsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RainbowStreakApp
    private val streakRepo = app.streakRepository
    private val analyticsRepo = app.analyticsRepository

    val isAnalyticsEnabled: StateFlow<Boolean> = analyticsRepo.isAnalyticsEnabled
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    val streaks: StateFlow<List<StreakEntity>> = streakRepo.allStreaks
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val analytics: StateFlow<AnalyticsEntity?> = analyticsRepo.analytics
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )
}
