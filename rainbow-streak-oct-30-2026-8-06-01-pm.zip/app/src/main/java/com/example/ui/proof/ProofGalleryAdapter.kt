package com.example.ui.proof

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.data.entity.ProofEntity
import com.example.databinding.ItemProofGalleryBinding
import java.io.File

class ProofGalleryAdapter(
    private val onProofClick: (ProofEntity) -> Unit
) : ListAdapter<ProofEntity, ProofGalleryAdapter.ProofViewHolder>(ProofDiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProofViewHolder {
        val binding = ItemProofGalleryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ProofViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProofViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ProofViewHolder(private val binding: ItemProofGalleryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(proof: ProofEntity) {
            binding.tvDayNumber.text = "${proof.dayNumber}. Day"
            binding.ivVideoIndicator.visibility = if (proof.isVideo) View.VISIBLE else View.GONE

            val file = File(proof.filePath)
            if (file.exists()) {
                binding.ivProofThumb.load(file) {
                    crossfade(true)
                }
            }

            binding.root.setOnClickListener {
                onProofClick(proof)
            }
        }
    }

    object ProofDiffCallback : DiffUtil.ItemCallback<ProofEntity>() {
        override fun areItemsTheSame(oldItem: ProofEntity, newItem: ProofEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ProofEntity, newItem: ProofEntity): Boolean {
            return oldItem == newItem
        }
    }
}
