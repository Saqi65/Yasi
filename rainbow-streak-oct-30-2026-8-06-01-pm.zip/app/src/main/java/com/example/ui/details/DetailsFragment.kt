package com.example.ui.details

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.MainActivity
import com.example.databinding.FragmentDetailsBinding
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DetailsFragment : Fragment() {

    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DetailsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnOpenSettingsFromDetails.setOnClickListener {
            (activity as? MainActivity)?.selectTab(MainActivity.TAB_SETTINGS)
        }

        observeData()
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(
                    viewModel.isAnalyticsEnabled,
                    viewModel.streaks,
                    viewModel.analytics
                ) { isEnabled, streaks, analytics ->
                    Triple(isEnabled, streaks, analytics)
                }.collect { (isEnabled, streaks, analytics) ->
                    if (!isEnabled) {
                        // Blurred / Disabled screen
                        binding.layoutAnalyticsDisabledOverlay.visibility = View.VISIBLE
                    } else {
                        binding.layoutAnalyticsDisabledOverlay.visibility = View.GONE

                        // Top Stats
                        binding.tvActiveStreaksCount.text = streaks.size.toString()
                        val sumScore = streaks.sumOf { it.currentStreak }
                        binding.tvSumStreakScore.text = sumScore.toString()

                        // Best Current
                        val bestCurrent = streaks.maxOfOrNull { it.currentStreak } ?: 0
                        binding.tvBestCurrentStreak.text = bestCurrent.toString()

                        // Analytics entity stats
                        val highestEver = maxOf(analytics?.highestStreakEver ?: 0, bestCurrent)
                        binding.tvHighestStreakEver.text = highestEver.toString()
                        binding.tvTotalAdRestores.text = (analytics?.totalAdRestores ?: 0).toString()
                        binding.tvTotalCheckIns.text = (analytics?.totalCheckIns ?: 0).toString()
                        binding.tvProofsCaptured.text = (analytics?.totalProofsCaptured ?: 0).toString()
                        binding.tvBrokenStreaks.text = (analytics?.streaksBrokenCount ?: 0).toString()

                        val firstCreated = analytics?.firstStreakCreatedAt ?: 0L
                        if (firstCreated > 0L) {
                            val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
                            binding.tvFirstStreakDate.text = sdf.format(Date(firstCreated))
                        } else if (streaks.isNotEmpty()) {
                            val earliest = streaks.minOf { it.createdAt }
                            val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
                            binding.tvFirstStreakDate.text = sdf.format(Date(earliest))
                        } else {
                            binding.tvFirstStreakDate.text = "None yet"
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
