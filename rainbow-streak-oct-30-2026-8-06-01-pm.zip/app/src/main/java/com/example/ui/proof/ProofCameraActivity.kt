package com.example.ui.proof

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.Chronometer
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import coil.load
import com.example.R
import com.example.databinding.ActivityProofCameraBinding
import java.io.File
import java.util.UUID

class ProofCameraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProofCameraBinding
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var isPhotoMode = true
    private var capturedFile: File? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        if (cameraGranted) {
            startCamera()
        } else {
            Toast.makeText(this, "Camera permission is required to capture proof", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProofCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        checkPermissionsAndStartCamera()
    }

    private fun setupListeners() {
        binding.btnCloseCamera.setOnClickListener {
            cleanupTempFile()
            finish()
        }

        binding.btnModePhoto.setOnClickListener {
            if (recording != null) return@setOnClickListener
            setMode(true)
        }

        binding.btnModeVideo.setOnClickListener {
            if (recording != null) return@setOnClickListener
            setMode(false)
        }

        binding.btnShutter.setOnClickListener {
            if (isPhotoMode) {
                takePhoto()
            } else {
                toggleVideoRecording()
            }
        }

        binding.btnRetake.setOnClickListener {
            cleanupTempFile()
            binding.layoutReviewOverlay.visibility = View.GONE
            binding.videoCapturedPreview.stopPlayback()
            binding.videoCapturedPreview.visibility = View.GONE
            binding.ivCapturedPhotoPreview.visibility = View.GONE
        }

        binding.btnConfirmProof.setOnClickListener {
            val file = capturedFile
            if (file != null && file.exists()) {
                val resultIntent = Intent().apply {
                    putExtra(EXTRA_CAPTURED_PATH, file.absolutePath)
                    putExtra(EXTRA_IS_VIDEO, !isPhotoMode)
                }
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }
    }

    private fun setMode(photo: Boolean) {
        isPhotoMode = photo
        if (photo) {
            binding.btnModePhoto.setBackgroundResource(R.drawable.bg_pill_selected)
            binding.btnModePhoto.setTextColor(ContextCompat.getColor(this, R.color.brand_orange))
            binding.btnModeVideo.setBackgroundResource(android.R.color.transparent)
            binding.btnModeVideo.setTextColor(ContextCompat.getColor(this, R.color.grey_unselected))
            binding.ivShutterIcon.setImageResource(R.drawable.ic_camera)
        } else {
            binding.btnModeVideo.setBackgroundResource(R.drawable.bg_pill_selected)
            binding.btnModeVideo.setTextColor(ContextCompat.getColor(this, R.color.brand_orange))
            binding.btnModePhoto.setBackgroundResource(android.R.color.transparent)
            binding.btnModePhoto.setTextColor(ContextCompat.getColor(this, R.color.grey_unselected))
            binding.ivShutterIcon.setImageResource(R.drawable.ic_video)
        }
    }

    private fun checkPermissionsAndStartCamera() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder().build()

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.SD))
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageCapture,
                    videoCapture
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Failed to start camera: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val imageCap = imageCapture ?: return
        val tempFile = File(cacheDir, "proof_${UUID.randomUUID()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()

        imageCap.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    capturedFile = tempFile
                    showReviewOverlay(tempFile, isVideo = false)
                }

                override fun onError(exception: ImageCaptureException) {
                    Toast.makeText(this@ProofCameraActivity, "Photo capture failed", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    private fun toggleVideoRecording() {
        val videoCap = videoCapture ?: return

        if (recording != null) {
            // Stop recording
            recording?.stop()
            recording = null
            binding.tvRecordingTimer.visibility = View.GONE
            binding.ivShutterIcon.setImageResource(R.drawable.ic_video)
            return
        }

        // Start recording
        val tempFile = File(cacheDir, "proof_${UUID.randomUUID()}.mp4")
        val outputOptions = FileOutputOptions.Builder(tempFile).build()

        val recordingBuilder = videoCap.output.prepareRecording(this, outputOptions)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            recordingBuilder.withAudioEnabled()
        }

        binding.tvRecordingTimer.visibility = View.VISIBLE
        binding.tvRecordingTimer.text = "00:00"
        binding.ivShutterIcon.setImageResource(R.drawable.ic_check)

        recording = recordingBuilder.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Finalize -> {
                    if (!event.hasError()) {
                        capturedFile = tempFile
                        showReviewOverlay(tempFile, isVideo = true)
                    } else {
                        Toast.makeText(this, "Video recording failed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun showReviewOverlay(file: File, isVideo: Boolean) {
        binding.layoutReviewOverlay.visibility = View.VISIBLE
        if (isVideo) {
            binding.videoCapturedPreview.visibility = View.VISIBLE
            binding.ivCapturedPhotoPreview.visibility = View.GONE
            binding.videoCapturedPreview.setVideoURI(Uri.fromFile(file))
            binding.videoCapturedPreview.start()
        } else {
            binding.ivCapturedPhotoPreview.visibility = View.VISIBLE
            binding.videoCapturedPreview.visibility = View.GONE
            binding.ivCapturedPhotoPreview.load(file)
        }
    }

    private fun cleanupTempFile() {
        capturedFile?.let {
            if (it.exists()) it.delete()
        }
        capturedFile = null
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanupTempFile()
    }

    companion object {
        const val EXTRA_CAPTURED_PATH = "extra_captured_path"
        const val EXTRA_IS_VIDEO = "extra_is_video"
    }
}
