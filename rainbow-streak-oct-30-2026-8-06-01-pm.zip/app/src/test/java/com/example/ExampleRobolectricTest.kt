package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.config.StreakStyleConfig
import com.example.data.model.Frequency
import com.example.util.StreakPeriodHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Rainbow Streak", appName)
    }

    @Test
    fun `test flame drawables and thresholds`() {
        assertEquals(R.drawable.ic_fire_level1, StreakStyleConfig.getFlameDrawableRes(1))
        assertEquals(R.drawable.ic_fire_level1, StreakStyleConfig.getFlameDrawableRes(29))
        assertEquals(R.drawable.ic_fire_level2, StreakStyleConfig.getFlameDrawableRes(30))
        assertEquals(R.drawable.ic_fire_level2, StreakStyleConfig.getFlameDrawableRes(99))
        assertEquals(R.drawable.ic_fire_level3, StreakStyleConfig.getFlameDrawableRes(100))
        assertEquals(R.drawable.ic_fire_level3, StreakStyleConfig.getFlameDrawableRes(363))
        assertEquals(R.drawable.ic_fire_level4, StreakStyleConfig.getFlameDrawableRes(364))
        assertEquals(R.drawable.ic_fire_level4, StreakStyleConfig.getFlameDrawableRes(500))
    }

    @Test
    fun `test streak duration formatting`() {
        assertNull(StreakStyleConfig.formatStreakDuration(0))
        assertNull(StreakStyleConfig.formatStreakDuration(1))
        assertNull(StreakStyleConfig.formatStreakDuration(3))

        val duration4 = StreakStyleConfig.formatStreakDuration(4)
        assertEquals("4 Days", duration4)

        val duration721 = StreakStyleConfig.formatStreakDuration(721)
        assertEquals("1 Year, 11 Months, 26 Days", duration721)
    }

    @Test
    fun `test flame color stop exact values`() {
        assertEquals(StreakStyleConfig.COLOR_DAY_1, StreakStyleConfig.getFlameColor(0))
        assertEquals(StreakStyleConfig.COLOR_DAY_1, StreakStyleConfig.getFlameColor(1))
        assertEquals(StreakStyleConfig.COLOR_DAY_30, StreakStyleConfig.getFlameColor(30))
        assertEquals(StreakStyleConfig.COLOR_DAY_100, StreakStyleConfig.getFlameColor(100))
        assertEquals(StreakStyleConfig.COLOR_DAY_364, StreakStyleConfig.getFlameColor(364))
        assertEquals(StreakStyleConfig.COLOR_DAY_364, StreakStyleConfig.getFlameColor(500))
    }

    @Test
    fun `launch MainActivity`() {
        org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
    }
}
